<div id="fb-og-right">

	<div class="fb-og-admin-box">
		<h3>Help, ideas, or feedback?</h3>
		<div style="text-align:center;" class="fb-og-inner">
			<p style='font-weight:bold;'>Join our GetSatisfaction community:</p>
			<a class='button' href='https://getsatisfaction.com/fbsocialreader' target='blank' >Support Site</a>			
			<br/>
			<br/>
		</div>	
	</div>

	<div class="fb-og-admin-box">
		<h3>Want to contribute?</h3>
		<div style="text-align:center;" class="fb-og-inner">
			<p>We want to make the best social integration system possible. If you'd like to contribute, find us on GitHub.</p>
			<a class='button' href='https://getsatisfaction.com/fbsocialreader' target='blank' >Find us on GitHub</a>			
			<br/>
			<br/>
		</div>	
	</div>

	
</div>